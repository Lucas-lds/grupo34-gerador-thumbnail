import os
import boto3
import mysql.connector
from mysql.connector import Error

# Configurações do Cognito
cognito_client = boto3.client('cognito-idp', region_name='us-east-1')  # Ajuste a região

# Obter as variáveis de ambiente para conectar ao banco de dados
db_config = {
    'host': os.environ['DB_HOST'],  # Endpoint do seu RDS
    'user': os.environ['DB_USER'],
    'password': os.environ['DB_PASSWORD'],
    'database': os.environ['DB_NAME']
}

# Função para cadastrar um novo usuário no banco de dados após o login no Cognito
def register_user_in_database(cognito_user_id, username, email):
    try:
        # Conectando ao banco de dados MySQL
        connection = mysql.connector.connect(**db_config)
        cursor = connection.cursor()

        # Verifica se o usuário já existe no banco de dados
        cursor.execute("SELECT * FROM users WHERE cognito_user_id = %s", (cognito_user_id,))
        result = cursor.fetchone()

        # Se o usuário não existir, insere um novo registro
        if not result:
            cursor.execute(
                "INSERT INTO users (cognito_user_id, username, email) VALUES (%s, %s, %s)",
                (cognito_user_id, username, email)
            )
            connection.commit()
            print(f'User {username} registered successfully!')
        else:
            print(f'User {username} already exists in the database.')

    except Error as e:
        print(f"Error: {e}")
    finally:
        if connection.is_connected():
            cursor.close()
            connection.close()

# Função para simular o login no Cognito e persistir os dados
def handle_cognito_login(cognito_user_id):
    try:
        # Simula a recuperação de dados do usuário após o login no Cognito
        response = cognito_client.admin_get_user(
            UserPoolId=os.environ['COGNITO_USER_POOL_ID'],  # ID do seu Pool de Usuários Cognito
            Username=cognito_user_id  # ID do usuário no Cognito
        )
        
        username = response['Username']
        email = None

        # Extrair email do atributo de usuário (ajuste conforme seu pool de atributos)
        for attribute in response['UserAttributes']:
            if attribute['Name'] == 'email':
                email = attribute['Value']
        
        if email:
            # Chama a função para persistir os dados no banco de dados
            register_user_in_database(cognito_user_id, username, email)
        else:
            print('Email not found in Cognito user attributes.')

    except cognito_client.exceptions.UserNotFoundException:
        print(f"User with Cognito User ID {cognito_user_id} not found.")
    except Exception as e:
        print(f"Error: {e}")

# Exemplo de uso com um ID fictício do Cognito
handle_cognito_login('cognito-user-id-12345')
