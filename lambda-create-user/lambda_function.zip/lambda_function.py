import os
import boto3
import json
from botocore.exceptions import ClientError
from datetime import datetime

# Criar o cliente Cognito
cognito_client = boto3.client('cognito-idp', region_name='us-east-1')

# Função para serializar objetos datetime
def json_serializer(obj):
    if isinstance(obj, datetime):
        return obj.isoformat()
    raise TypeError(f"Tipo {type(obj)} não é serializável para JSON")

def lambda_handler(event, context):
    try:
        # Recuperar os dados do usuário a partir do evento
        body = json.loads(event['body'])
        username = body.get('username')
        email = body.get('email')
        password = body.get('password')  # A senha deve ser tratada de forma segura

        if not username or not email or not password:
            raise Exception("Campos obrigatórios ausentes: username, email ou password.")

        # Preparar os parâmetros para criar o usuário no Cognito
        response = cognito_client.admin_create_user(
            UserPoolId=os.environ['COGNITO_USER_POOL_ID'],  # ID do seu pool de usuários no Cognito
            Username=username,
            UserAttributes=[
                {
                    'Name': 'email',
                    'Value': email
                },
                {
                    'Name': 'email_verified',
                    'Value': 'true'
                },
            ],
            TemporaryPassword=password,  # Define a senha temporária do usuário
            MessageAction='SUPPRESS'  # Suprime o envio de e-mails automáticos
        )

        # Após a criação, define a senha permanente do usuário
        cognito_client.admin_set_user_password(
            UserPoolId=os.environ['COGNITO_USER_POOL_ID'],
            Username=username,
            Password=password,  # Aqui definimos uma senha mais segura se necessário
            Permanent=True
        )
        
        return {
            'statusCode': 200,
            'body': json.dumps({
                'message': f'Usuário {username} criado com sucesso no Cognito.',
                'user': response['User']
            }, default=json_serializer) # Usa a função personalizada para serializar objetos datetime
        }
    
    except ClientError as e:
        # Captura de erros específicos do Cognito
        return {
            'statusCode': 400,
            'body': json.dumps({
                'error': str(e),
            })
        }
    except Exception as e:
        # Captura de erros gerais
        return {
            'statusCode': 500,
            'body': json.dumps({
                'error': str(e),
            })
        }